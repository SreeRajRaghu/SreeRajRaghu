from . import account_journal_inherit
from . import account_payment_inherit
from . import account_move_inherit
